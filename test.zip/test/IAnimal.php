<?php
/**
* defining  the interface
*/
interface IAnimal
{
  const CAN_FLY_MSG     = "I'm flying high";
  const CAN_NOT_FLY_MSG = "I can't fly";
  public function tryToFly();
  public function talk();
}

<?php
require_once "Color.php";
class Blue implements Color {

	public function fill() {
		echo "Blue color is filling..";
	}
}
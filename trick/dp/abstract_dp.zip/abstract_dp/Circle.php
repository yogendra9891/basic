<?php
require "Shape.php";
class Circle implements Shape {

    public function draw() {
		echo "Circle is drawing...";
	}
 
}
<?php
interface Color {
 public function fill();
}
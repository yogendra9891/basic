<?php
require_once "Color.php";
class Red implements Color {

	public function fill() {
		echo "Red color is filling..";
	}
}
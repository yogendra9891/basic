<?php
interface Shape {
 public function draw();
}